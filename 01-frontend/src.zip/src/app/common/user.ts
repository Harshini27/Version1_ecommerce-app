export class User {
    userid:number;
    address:string;
    email:string;
    fname:string;
    lname:string;
    mobile:string;
    
}
